from .gcn import GCN
from .gat import GAT
from .gin import GIN
